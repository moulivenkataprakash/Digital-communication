clear all;
info=['b' 'b' 'b' 'c' 'c' 'b' 'a' 'd' 'a' 'e' ' ' 'g' 'j'];
info=char(importdata('input.txt'));          %information
%info=['a' 'a' 'a' 'a' 'a' 'b' 'b' 'c' 'c' 'c' 'd' 'e' 'e' 'e' 'e' 'e' 'e' 'e' 'e' 'f'];
[encoded_bits,encoded]=huffmann_encoder(info)                     %calling encoder
decoded=huffmann_decoder(encoded_bits,encoded);                    %calling decoder
isequal(info,decoded)                                             %checking whether decoded equal to information