function [encoded_bits,encoded]=huffmann_encoder(info)
symbols=(unique(info))';                                 %getting all uniqe charecters
probab=((histc(info,symbols))/length(info))';            %getting probabilities of each charecter
in_prob=[(1:(length(probab)))' probab];                        %indexing all probabilities
so_prob=sortrows(in_prob,2,'descend');                            %sorting probabilities
path(:,1)=so_prob(:,1);                                           %storing indexes in path
k=length(so_prob);                                                 %length of unique charecters
encoded=string(repmat(' ',k));                                  %taking dummy array of encoded
for i=1:k-2
    so_prob(length(so_prob)-1,2)=so_prob(length(so_prob)-1,2)+so_prob(length(so_prob),2);%adding last two prababilities
    so_prob=so_prob((1:length(so_prob)-1),:);                                   %eliminating last probabilities
    so_prob=[so_prob(length(so_prob),:); so_prob((1:length(so_prob)-1),:)];      %shifting last probability to top
    so_prob = sortrows(so_prob,2,'descend');                                    %sorting probabilities
    path([1:k-i],i+1)=so_prob(:,1);                                              %appending indices to path
end
%indices for trace back stored in path
n=1;
for i=k-1:-1:1
    if n ~= 1
    encoded(path(n+1,i))=(string(encoded(path(n,i))+encoded(path(n+1,i))));     %assigning content of last 2 index to last indexed symbol
    end
    encoded(path(n,i))=string(encoded(path(n,i))+ string(0));                  %appending 0 to last 2nd indexed symbol
    encoded(path(n+1,i))=string(encoded(path(n+1,i)) + string(1));             %appending 0 to last indexed symbol
    n=n+1;
end
%symbols=symbols(path(:,1));
for i=1:k
temp=char(encoded(i,:));
encoded(i,:)=string(temp(temp~=' '));          %for avoiding spaces in symbols
end
encoded(:,2)=encoded(:,1);                      %assigning symbols to first column    
encoded(:,1)=symbols;%(path(:,1));              %assigning symbols to first column
encoded_bits=[];                                %defing array for encoded bits
%assigning symbols to each charecter in information
for i=1:length(info)
[a b]=ismember(info(i),encoded(:,1));           %getting index of which symbol to assign     
encoded_bits=[encoded_bits  string(encoded(b,2))];        %appending that symbol bits
end
encoded_bits=(reshape(char(encoded_bits),1,[]));      %reshping 
encoded_bits=encoded_bits(encoded_bits~=' ');          %removing spaces
encoded_bits=(encoded_bits-' ')-16;                    %converting to bits
end
