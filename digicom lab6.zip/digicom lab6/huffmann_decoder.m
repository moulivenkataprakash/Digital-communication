function decoded=huffmann_decoder(encoded_bits,encoded)
i=1;
code=' ';             %dummy variable
decoded=[];           %defing decoded
while i<=length(encoded_bits)
 
 code = string(code)+string(encoded_bits(i));  %appending next bit for matching to dictionary
 code=char(code);
 code=string(code(code~=' '));                   %removing spaces
 if ismember(code,encoded(:,2))                   %checking if code is any of symbol bits
 [a b]=ismember(code,encoded(:,2));               %tacking the index
 decoded= [decoded encoded(b,1)];                  %appending charectar corresponding to symbol bits
 code=' ';                                          %empting temporory variable
 end
 i = i + 1;                                        %incrementing index
end
decoded=reshape(char(decoded),1,[]);               %reshaping to get interms of char
end