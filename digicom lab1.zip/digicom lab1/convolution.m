
syms x t
y1=f1(x);
y2=f2(t-x);
y3=f2(x);
y4=f1(t);
y5=f2(t);
i = inline(int(sin(x).*cos(t-x),x,0,15));
t=-0:0.5:120;
y=i(t);
plot(t,y); 
hold on;
t=-15:0.5:15;
s=sin(t); 
h=cos(t);
w = conv(s,h,"full");
plot(w);
function y1=f1(l)
 y1=sin(l);
end
function y2=f2(l)
y2=cos(l);
end