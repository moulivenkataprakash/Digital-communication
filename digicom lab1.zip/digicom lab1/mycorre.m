function w=mycorre(x1,x2)
   x3=flip(x2);  %fliping the one of the signal
   w=myconv(x1,x3); %calling my convoluting function
end