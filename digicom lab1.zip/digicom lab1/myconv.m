function C=myconv(x1,x2)
      
   int B(:,:) = 0;
       C=[];
for i=1:length(x1)
    for j=1:length(x2)
    int  B(i,j)=x1(i).*x2(j);  %creating matrix of elements that contain product sum of elements of two input signals
    end
end  
for k=1:(length(x1)+length(x2)-1)  %loop for checking elements of B that have same indices sum
   sum=0;
   for i=1:length(x1)
    for j=1:length(x2)
     if k+1==i+j      
      sum=sum+B(i,j);      %creating elements of convoluted signals
     end
    end
   end
   C=[C,sum];        %assigning elements of convoluted signals in C
end  
end