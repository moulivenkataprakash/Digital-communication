fs= 40;
dt= 1/fs;
t= 0:dt:5;
ac= 5;
am=10;
fm= 1;
fc= 10;
x1= cos(2*pi*fm*t); %input message signals for system
x2= sin(2*pi*fm*t);
x3= ac.*x1 + am.*x2;%sum of scaled inputs.
x1=1;
x2=2;
x3= ac.*x1 + am.*x2;
y1=myfun(x1,t);
y2=myfun(x2,t);
y3=myfun(x3,t);
yt=ac.*y1 + am.*y2 ;
if (y3 - yt)<=(10^(-1))    %checking if y3 and yt equal or not
  disp("given system is linear");
else
   disp("given system is not linear");
end

x=t;  %input signal for checking time invarience
y=myfun(x,t);
t=t-0.3;
dy=myfun(x,t);
if y - dy <= 10^(-1)  %checking the euality of signal of delayed input to delay output
    disp("it is time invariant ");
else 
    disp("it is time varient");
end
function y = myfun(x,t)
%  y = sin(t).*x;
   y=x+1;          %system function
end
