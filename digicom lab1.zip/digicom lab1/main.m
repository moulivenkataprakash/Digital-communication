t=1:30;
x1=f1(t);
x2=f2(t);
Convoluted=myconv(x1,x2); %using myconvolution function
correlated=mycorre(x1,x2);%using mycorre function
disp(Convoluted);
s=x1; 
h=x2;
inbuilt_convoluted = conv(s,h); %using inbuilt convolution function
inbuilt_correlated=xcorr(s,h);%using inbuilt correlation function
function y1=f1(l)
 y1=sin(2*(3.14)*(0.2).*l);  %input signal 1
end
function y2=f2(l)
y2=cos(2*(3.14)*(0.2).*l); %input signal 2
end