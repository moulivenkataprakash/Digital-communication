clear all;
info=['b' 'b' 'b' 'c' 'c' 'b' 'a' 'd' 'a' 'e' 'f' 'g'];
[encoded_bits,encoded]=huffmann_encoder(info);
decoded=huffmann_decoder(encoded_bits,encoded);
isequal(info,decoded)