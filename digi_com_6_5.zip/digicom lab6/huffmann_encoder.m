function [encoded_bits,encoded]=huffmann_encoder(info)
symbols=(unique(info))';
probab=((histc(info,symbols))/length(info))';
p=[(1:(length(probab)))' probab];
de=sortrows(p,2,'descend');
path(:,1)=de(:,1);
k=length(de);
encoded=string(repmat(' ',k));
for i=1:k-2
    de(length(de)-1,2)=de(length(de)-1,2)+de(length(de),2);
    de=de((1:length(de)-1),:);
    de=[de(length(de),:); de((1:length(de)-1),:)];
    de = sortrows(de,2,'descend');
    path([1:k-i],i+1)=de(:,1);
end
n=1;
for i=k-1:-1:1
    if n ~= 1
    encoded(path(n+1,i))=(string(encoded(path(n,i))+encoded(path(n+1,i))));
    end
    encoded(path(n,i))=string(encoded(path(n,i))+ string(0));
    encoded(path(n+1,i))=string(encoded(path(n+1,i)) + string(1)); 
    n=n+1;
end
for i=1:k
temp=char(encoded(i,:));
encoded(i,:)=string(temp(temp~=' '));
end
encoded(:,2)=encoded(:,1);
encoded(:,1)=symbols(path(:,1));
encoded_bits=[];
for i=1:length(info)
[a b]=ismember(info(i),encoded(:,1));
encoded_bits=[encoded_bits  string(encoded(b,2))];
end
encoded_bits=(reshape(char(encoded_bits),1,[]));
encoded_bits=encoded_bits(encoded_bits~=' ');
encoded_bits=(encoded_bits-' ')-16;
end
