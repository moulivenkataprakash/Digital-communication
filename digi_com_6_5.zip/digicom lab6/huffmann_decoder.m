function decoded=huffmann_decoder(encoded_bits,encoded)
i=1;
code=' ';
decoded=[];
while i<=length(encoded_bits)
 
 code = string(code)+string(encoded_bits(i));
 code=char(code);
 code=string(code(code~=' '));
 if ismember(code,encoded(:,2))
 [a b]=ismember(code,encoded(:,2));
 decoded= [decoded encoded(b,1)];
 code=' ';
 end
 i = i + 1;
end
decoded=reshape(char(decoded),1,[]);
end