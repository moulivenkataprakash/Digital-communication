function convolutional_decoded=convolutional_decoder(encodebits)
%encodebits=bitxor(convolutional_encoded,[1 0 0 1 0 0 0 0 1 0 0 0 ]);
trellis_paths=[0,1; 2,3;0,1;2,3];
trellispath_outputs=[0,0; 1,1; 0,1;1,0; 1,1;0,0; 1,0; 0,1];
weight_of_previous_states=[0; 0; 0 ;0];
index=1;
for i = 1:2:length(encodebits) 
    present_two_bits = encodebits(i:i+1);
    
    for Statei = 0:3 
        
        First_path_output = trellispath_outputs(2*Statei+1,:);
        second_path_output = trellispath_outputs(2*Statei+2,:);
        P_f_weight=sum(bitxor(present_two_bits ,First_path_output));
        P_s_weight=sum(bitxor(present_two_bits,second_path_output));
        weightFirst = weight_of_previous_states(trellis_paths(Statei+1,1)+1,index) + P_f_weight;
        weightSecond = weight_of_previous_states(trellis_paths(Statei+1,2)+1,index) + P_s_weight;
        
        [tempweight(Statei+1),path]=min([weightFirst weightSecond]);
        if (i==1)  && (Statei==0 || Statei==2)
            tempweight(Statei+1)=weightFirst;
            path=1;
        elseif  i==1 && (Statei==1 || Statei==3) 
            tempweight(Statei+1)=0;
            path=1;
        elseif  i==3  
            tempweight(Statei+1)=weightFirst;
            path=1; 
        end
       
        Index_of_paths(Statei+1,index) = trellis_paths(Statei+1,path);
            
    end  
    index = index+ 1;
    weight_of_previous_states(:,index) = tempweight';
   
end
[a,m]=min(weight_of_previous_states(:,index));
m=m-1;
m=0;
for i=length(encodebits)/2:-1:1

 if m==0
    convolutional_decoded(i)=0;
 elseif m==1

    convolutional_decoded(i)=0;
 else
     convolutional_decoded(i)=1;
 end
m=Index_of_paths(m+1,i);
end
end
    
   
    
    
   
   
