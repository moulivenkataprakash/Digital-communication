clc;
clear;
clear all;
data=[0;0;1;0;0;0];
convolutional_encoded=convolutional_encoder(data)
received=bitxor(convolutional_encoded,[0 0 0 1 0 0 1 1 0 0 0 0])
convolutional_decoded=convolutional_decoder(received);