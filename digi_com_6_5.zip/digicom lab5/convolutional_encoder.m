function convolutional_encoded=convolutional_encoder(data)
initial=[0;0];
k=1;
for i=1:length(data)
 outreg=bitxor(initial(2,1),initial(1,1));
convolutional_encoded(k)=bitxor(data(i,1),initial(2,1));
 k=k+1;
 convolutional_encoded(k)=bitxor(data(i,1),outreg);
 k=k+1;
initial(2,1)=initial(1,1);  
initial(1,1)=data(i);
end
end



