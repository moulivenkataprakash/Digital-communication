function interbits=myinterleaver(TxBits,norepeti)
 rbits=reshape(TxBits,norepeti,[]);%reshaping ,so that "norepeti" + 1 th bit comes below the first bit in matrix
 interbits=reshape(rbits',1,[]);%reshaping to read column wise
end