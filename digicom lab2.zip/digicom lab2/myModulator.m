function [xMod] = myModulator(TxBits,constellation)
 
 s=log2(length(constellation));
  reshtx= reshape((TxBits),s,[]);%reshaping depends on modulation
  reshtx=reshtx';
  chresh=int2str(reshtx);%converting bits to string so that we can convert to decimals
  symnumvec=bin2dec(chresh);%converting to decimals
       for n=1:length(reshtx)
           T=symnumvec(n);
           xMod(n)= constellation(T+1);% alloting costillation points
       end
      
end

