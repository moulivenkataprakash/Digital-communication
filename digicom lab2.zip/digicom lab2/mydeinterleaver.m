function deinterbits=mydeinterleaver(demodbits,norepiti)
 rbits=reshape(demodbits,[],norepiti);%reshaping to to make copied bits to be in same row
 deinterbits=reshape(rbits',1,[]);%complementing and reading it in column wise
end