clc;
clear 
close all
modType= 'QPSK';%taking modulation type
numbits = 100000;%number of bits
TxBits = rand(numbits,1)>0.5;%generating bits
TxBits =TxBits';
% TxBits=[1 1 0 0 ];
snr = 0:2:16; %snr array
len_snrs = length(snr);
if modType=='QPSK'
escalef=sqrt(1/(2));  %creating scaling fctor to make constelation point unit energy
constellation = [1+1i ,-1+1i,-1-1i,1-1i];%defining constellation array for qpsk
end
if modType=='BPSK'
escalef=1;  %creating scaling fctor to make constelation point unit energy
constellation = [1,-1];%defining constellation array for qpsk
end
norepeti=3;% giving no of repetitions we need in encoder
encbits=myencoder(TxBits,norepeti);%calling encoder function
interbits=myinterleaver(encbits,norepeti);%calling my interleaver function
[xMod] = myModulator(interbits,constellation);%calling modulator function
%SNR for loop
for k=1:len_snrs %creating snr loop
    snr_now = snr(k); 
    snrindb=10^(snr_now/20);%snr in decibels

    noise=randn(length(xMod),1)+1i*randn(length(xMod),1); %generating awgn noice
    received = xMod*escalef + ((1/snrindb)*noise)'; %adding noice to modulated signal
    [demod_symbols,demod_bits] = myDemodulator(received,constellation);%calling demodulator function
    deinterbits=mydeinterleaver(demod_bits,norepeti);%calling mydeinterleaver function
    decbits=mydecoder(deinterbits,norepeti);%calling my decoder function
    errorsb = 0;
    for n=1:length(decbits) %generating loop for calculating bit errors
        if decbits(n) ~= TxBits(n)
            errorsb = errorsb + 1;
        end
    end
     perb_estimate(k) = errorsb/numbits;
      errorss = 0;
    for n=1:length(demod_symbols)%generating loop for calculating symbol errors
        if demod_symbols(n) ~= xMod(n)
            errorss = errorss + 1;
        end
    end
     pers_estimate(k) = errorss/length(xMod);
end
semilogy(snr,perb_estimate);%plotting bit eroor vs snr
hold on
semilogy(snr,pers_estimate);%plotting symbol eroor vs snr
grid on
legend("bit error ","symbol error"); 
xlabel("SNR");
ylabel(" Error Rate");
title('with awgn noice');
