function [demod_out_symbol, demod_bits]= myDemodulator(received,constellation)
      for n=1:length(received)
       distances = abs(received(n)-constellation);  %calculating distance from each constallation ponts  
       [min_dist,decisions(n)] = min(distances);%caiculating index of constellation
       demod_out_symbol(n) = constellation(decisions(n));%assigning demod symbols
       demod_symnumvec(n) = decisions(n) - 1;%demod number vector 
      end
      %converting back to bits
       demod_bits = dec2bin(demod_symnumvec);%we get string here
       demod_bits = (str2num(reshape(demod_bits',[],1)));%converting string to bits

end