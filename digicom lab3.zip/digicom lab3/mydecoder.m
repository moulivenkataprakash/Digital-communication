function decbits=mydecoder(deinterleavedbits,norepiti)
 rsbits=reshape(deinterleavedbits,norepiti,[]);%reshaping to make all repeated bits of each bit to be in same column
 decbits=mode(rsbits);%gives the most appeared bit in each column
end