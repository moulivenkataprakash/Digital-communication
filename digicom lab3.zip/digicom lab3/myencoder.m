function encbits=myencoder(TxBits,norepiti)
 TxBits=reshape(TxBits,1,[]);%reshaping to row vector
 rbits=repmat(TxBits,norepiti,1);%repeating each row "norepiti" times
 encbits=reshape(rbits,1,[]);%again reshaping to row vector
end