clc;
clear;
clear all;
data=[0;0;1;0;0;0];             %message
g1=[1 0 1];                      %m1 configuration
g2=[1 1 1];                       %m2 configuration
trellis_paths=[0,1; 2,3;0,1;2,3];       %each row contain states from where it can be reached
trellispath_outputs=[0,0; 1,1; 0,1;1,0; 1,1;0,0; 1,0; 0,1];           %outputs of each possible transition
convolutional_encoded=convolutional_encoder(data,g1,g2)                 %calling encoder
received = bitxor(convolutional_encoded,[1 0 0 1 0 0 0 0 0 0 1 0])       %adding Noice
convolutional_decoded=convolutional_decoder(received,trellis_paths,trellispath_outputs);  %calling decoder