function convolutional_encoded=convolutional_encoder(data,g1,g2)
initial=[0;0];
k=1;
for i=1:length(data)                                          %taking loop for each bit
 outreg=bitxor(g1(2)*initial(1,1),g1(3)*initial(2,1));          %m1 and m2 addition for first output 
 outreg1=bitxor(g2(2)*initial(1,1),g2(3)*initial(2,1));         %m1 and m2 addition for second output 
convolutional_encoded(k)=bitxor(g1(1)*data(i,1),outreg);        %encoded out bit one
 k=k+1;                                                          %increment of index of encoded bits
 convolutional_encoded(k)=bitxor(g2(1)*data(i,1),outreg1);      %encoded out bit one  
 k=k+1;
initial(2,1)=initial(1,1);                                      %shifting content of memory block 1 to 2
initial(1,1)=data(i);                                           %shifting data in in memory block 1
end
end



