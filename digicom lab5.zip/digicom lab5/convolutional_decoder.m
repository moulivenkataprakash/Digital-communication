
function convolutional_decoded=convolutional_decoder(received,trellis_paths,trellispath_outputs)
weights=[0; 0; 0 ;0];                        %assigning initial weigths as zeroes
index=1;                                     
statez=find(trellis_paths==0)-1;              %finding states where zero state can go
for i = 1:2:length(received)                  %declaring loop ,taking two bits at a time
    present_two_bits = received(i:i+1);
    
    for Statei = 0:3                             %for each memory state
        
        Firstoutput = trellispath_outputs(2*Statei+1,:); %first output possible for state
        secondoutput = trellispath_outputs(2*Statei+2,:);%second output possible for state
        P_f_weight=sum(bitxor(present_two_bits ,Firstoutput));%weight generated in present state for first path
        P_s_weight=sum(bitxor(present_two_bits,secondoutput));%weight generated in present state for second path
        weightFirst = weights(trellis_paths(Statei+1,1)+1,index) + P_f_weight;%toatal weight including previous weight for path one
        weightSecond = weights(trellis_paths(Statei+1,2)+1,index) + P_s_weight;%toatal weight including previous weight for path two
        de_weight=[weightFirst weightSecond];              %total weights in array
        [tempweight(Statei+1),path]=min([weightFirst weightSecond]);   %tacking min weight and index as path
        if (i==1)  && (ismember(Statei+1,find(trellis_paths==0)))
            tempweight(Statei+1)=weightFirst;                        %for initial states it will be always first path
            path=1;
        elseif  i==1 && (~ismember(Statei+1,find(trellis_paths==0))) 
            tempweight(Statei+1)=0;                                   %we wont assign any weight for states in which 00 state cant reach for first two bits
            path=1;
        elseif  i==3
            pos_paths=[find(trellis_paths(Statei+1,:)==statez(1)) find(trellis_paths(Statei+1,:)==statez(2))];
            tempweight(Statei+1)=de_weight(pos_paths);                    %assigning weights for next two bits irrespective of min weights ,alloting possible
            path=pos_paths; %selecting possible path
        end 
       
        Index_of_paths(Statei+1,index) = trellis_paths(Statei+1,path);  %storing all indexces for trace back
            
    end  
    index = index+ 1;
    weights(:,index) = tempweight';        %stroring weights of each state for all bits
   
end
pr_index=0;                             %present index is 0,so trace back starts from 00 state
for i=length(received)/2:-1:1            
nextindex=pr_index;                       %storing present index in nextindex 
pr_index=Index_of_paths(pr_index+1,i);    %storing content of that present index to present index
if (nextindex<pr_index)
  convolutional_decoded(i)=0;             %next state will be of less value only if input is 0,so assign 0
elseif (nextindex>pr_index)
  convolutional_decoded(i)=1;             %next state will be of great value only if input is 1,so assign 1
elseif ([nextindex pr_index]==[0 0])
  convolutional_decoded(i)=0;             %level of both states equal means input is 0 or 1 based on state
else  ([nextindex pr_index]==[3 3]) 
  convolutional_decoded(i)=1;  
end

end
end


    
    
   
   
