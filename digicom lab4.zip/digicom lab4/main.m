clear all;
u=[0 1];%message signal
no_of_mes=(size(u));
no_of_mes=no_of_mes(1);  %no of messages signal
G=[1 0 1 0 1 ;0 1 0 1 1];   %generator matrix
gdime=size(G);
k=gdime(1);             %getting value of k from dimensions of generator matrix
n=gdime(2);             %getting value of n from dimensions of generator matrix  
codewords=mod(u*G,2);   %generating code words for transmission
dum_ma=G(:,k+1:n);       %dummy variable for storing parity matrix
H=[dum_ma' eye(n-k)];    %generating parity check matrix
dmin=min(sum(codewords'));   %d minimum value
for i=1:no_of_mes            %loop for generating standard array matrix
    stanarry(1,:,i)=codewords(i,:);     %alloting code word itself as first element in standard array matrix
    for j=1:n
        l=(dec2bin(2^(j-1),n)*1)-48;       %generating one bit error row to xor with code words(eg :[0 0 0 0 1 0])
        stanarry(j+1,:,i) = bitxor(codewords(i,:),l);     %alloting one bit error codewords in standard array matrix
    end 
    w=1;
     for k=1:n
        for s=k+1:n
         l=(dec2bin(2^(k-1),n)*1)-48;          %generating two differet one bit error codewords to xor with codeword at a time
         f=(dec2bin(2^(s-1),n)*1)-48;
        stanarry(w+1+n,:,i) = bitxor(bitxor(codewords(i,:),l),f);   %aloting 2 bit error codewords in standard array matrix
        w=w+1;
        end
    end 
    
end
received=codewords;
received(1,:)=[0 1 1 1 1];     %adding noice to 2nd  codeword and assining as received
stadecoded=standarry_decoder(received,stanarry,no_of_mes);     %calling standard array decoder
MLdecod_codewords= MLDecoder(received,codewords,no_of_mes); %calling mldecoder
syndrome_decoded=syndrome_decoder(received,H,n,no_of_mes);    % calling syndrome decoder
