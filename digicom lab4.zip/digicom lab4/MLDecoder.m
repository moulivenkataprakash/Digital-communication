function  MLdecod_codewords= MLDecoder(received,codewords,no_of_mes)
   
   for n=1:no_of_mes
       errarray=bitxor(received(1,:),codewords);   %difference between codewords and received
       d_errarry=sum(errarray');                     %calculating hamming weight of difference  matrix
       [min_dist,decisions(n)] = min(d_errarry);     %calculating index of minimum disatnced codeword
       MLdecod_codewords(n,:)=codewords(decisions(n),:);   %assigning minimum distanced codeword
   end
end