function stadecoded=standarry_decoder(received,stanarry,no_of_mes)

for i=1:no_of_mes
numstanarray(:,:,i)=bin2dec(int2str(stanarry(:,:,i)));   %converting codewords of standard array to decimal numbers ,so that we can comapare
numreceived(i,:)=bin2dec(int2str(received(i,:)));        %converting received codewords to decimal numbers
end
for i=1:no_of_mes                                        %for loop for checking each codewords
    for j=1:no_of_mes                                    %for loop for comparing with each element in standard array
    if (ismember(numreceived(i),numstanarray(:,:,j)))       
      stadecoded(i,:)=stanarry(1,:,j);                   %assining first code word of standard array which is correct codeword
    end
    end
end