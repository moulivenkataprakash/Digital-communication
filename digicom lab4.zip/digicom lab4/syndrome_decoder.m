function syndrome_decoded=syndrome_decoder(received,H,n,no_of_mes)
   syndrome=mod(received*H',2);       %calculating syndrome matrix
   syndrome_decoded=received;         %assigning received to decoded first ,so that we can change where ever error is
   h=H';
   for i=1:no_of_mes
     for j=1:n
       if syndrome(i,:)==h(j,:)       %checking every row of syndrome matrix if equal to any row in H transpose matrix,
          syndrome_decoded(i,:) = bitxor(received(i,:),(dec2bin(2^(n-j),n)*1)-48);  %if equal that index of row is idex of error bit in code word from left    
       end
     end
   end
end